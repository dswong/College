package edu.ucsb.cs.cs185.dswong.cameraroll;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class MultiTouchView extends ImageView
{
    Matrix draw = new Matrix();
    private int type; //0 is multiTouch scaling, 1 is multiTouch rotation, 2 is single tap, 3 is drag pan
    private float xPos;
    private float yPos;

    private ScaleGestureDetector mScaleDetector = new ScaleGestureDetector(getContext(),new ScaleListener());
    private float mScaleFactor = 1.f;

    public MultiTouchView(Context context)
    {
        this(context,null,0);
    }

    public MultiTouchView(Context context, AttributeSet attrs)
    {
        this(context,attrs,0);
    }

    public MultiTouchView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        if (type == 0) //multitouch, scaling
        {
            canvas.save();
            canvas.scale(mScaleFactor,mScaleFactor);
        }
        if (type == 1)
        {
            Paint paint = new Paint();
            paint.setColor(Color.RED);
            paint.setStrokeWidth(10);
            paint.setStyle(Paint.Style.FILL);
            paint.setAlpha(50);
            canvas.drawCircle(xPos,yPos,15,paint);
        }
        if (type == 2)
        {

        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent ev)
    {
        //Multi touch rotation, scaling in and out, type == 0
        if (ev.getPointerCount()==2)
        {
            //Multi touch rotation
            type = 0;
            mScaleDetector.onTouchEvent(ev);


            //scaling in out

        }
        else
        if (ev.getPointerCount()==1) //single touch event
        {

            //tap, type == 1
            if (ev.getAction()==MotionEvent.ACTION_DOWN)
            {
                type = 1;
                xPos = ev.getX();
                yPos = ev.getY();
                invalidate();
            }
            //pan, type == 2

        }
        return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener
    {
        @Override
        public boolean onScale(ScaleGestureDetector detector)
        {
            mScaleFactor *= detector.getScaleFactor();
            mScaleFactor = Math.max(0.1f,Math.min(mScaleFactor, 5.0f));
            invalidate();
            return true;
        }
    }
}
