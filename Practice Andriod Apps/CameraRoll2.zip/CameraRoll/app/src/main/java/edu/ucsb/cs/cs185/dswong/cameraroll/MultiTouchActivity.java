package edu.ucsb.cs.cs185.dswong.cameraroll;

import android.app.ActionBar;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.Window;
import android.widget.ImageView;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URI;


public class MultiTouchActivity extends ActionBarActivity {

    private static final int SELECT_PICTURE = 1;
    private String selectedPhotoPath;
    private MultiTouchView mTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String photoPath = intent.getStringExtra(MainActivity.PHOTO_URL); //get passed intent string

        setContentView(R.layout.activity_multi_touch); //set layout for this Activity
        mTV = (MultiTouchView)findViewById(R.id.multiTouchView); //get picture and set
        File f = new File(photoPath);
        Bitmap bitmap = BitmapFactory.decodeFile(f.getAbsolutePath());
        mTV.setImageBitmap(bitmap);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //to get back button
        getSupportActionBar().setDisplayShowTitleEnabled(false); //hide action bar title
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_multi_touch, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch(id)
        {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this); //go back to main activity
                return true;
            case R.id.load: //initiates load picture intent
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i,"Select Picture"),SELECT_PICTURE);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (resultCode == RESULT_OK)
        {
            if (requestCode == SELECT_PICTURE)
            {
                Uri selectedImageUri = data.getData();
                selectedPhotoPath = getRealPathFromURI_API19(this,selectedImageUri);
                Uri uriFromPath = Uri.fromFile(new File(selectedPhotoPath));
                Bitmap bitmap = null;
                try
                {
                    bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(uriFromPath));
                }
                catch (FileNotFoundException e)
                {
                    e.printStackTrace();
                }
                mTV.setImageBitmap(bitmap);
            }
        }
    }

    //method borrowed from hmkcode.com/android-display-selected-image-and-its-real-path/
    public static String getRealPathFromURI_API19(Context context, Uri uri)
    {
        String filePath = "";
        String wholeID = DocumentsContract.getDocumentId(uri);
        // Split at colon, use second item in the array
        String id = wholeID.split(":")[1];
        String[] column = { MediaStore.Images.Media.DATA };
        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";
        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel, new String[]{ id }, null);
        int columnIndex = cursor.getColumnIndex(column[0]);
        if (cursor.moveToFirst())
        {
            filePath = cursor.getString(columnIndex);
        }
        cursor.close();
        return filePath;
    }

}
