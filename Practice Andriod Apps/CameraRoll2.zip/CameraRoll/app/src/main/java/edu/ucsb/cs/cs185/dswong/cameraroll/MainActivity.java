package edu.ucsb.cs.cs185.dswong.cameraroll;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.melnykov.fab.FloatingActionButton;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends ActionBarActivity {

    public final static String PHOTO_URL = "";

    int photoNum = 0;
    ArrayList<String> fileNameList = new ArrayList<String>();

    private RecyclerView rView;
    private RecyclerView.Adapter rAdapter;
    private RecyclerView.LayoutManager rLayoutManager;
    TextView txtV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtV = (TextView)findViewById(R.id.noPhotosText);

        //fill file list with pre existing files
        String dirPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+"/CS185Pics";
        File f = new File(dirPath);
        File file[] = f.listFiles();
        for (int i=0;i<file.length;i++)
        {
            fileNameList.add(0,file[i].getAbsolutePath());
        }
        if (fileNameList.size()>0) //if there are files, don't show "no photos"
        {
            txtV.setText("");
        }

        //set up recycler
        rView = (RecyclerView)findViewById(R.id.recycler);
        rView.setHasFixedSize(true);
        rLayoutManager = new LinearLayoutManager(this);
        rView.setLayoutManager(rLayoutManager);
        rAdapter = new MyAdapter(fileNameList);
        rView.setAdapter(rAdapter);
        rAdapter.notifyDataSetChanged(); //in the event there were preexisting files in dir, must show

        //set up floating action button
        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //open camera
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (cameraIntent.resolveActivity(getPackageManager()) != null)
                {
                    File photo = null;
                    try
                    {
                        photo = createImageFile();
                    }
                    catch (IOException x)
                    {
                        Toast.makeText(MainActivity.this,"Failed to create file",Toast.LENGTH_LONG).show();
                    }
                    if (photo != null)
                    {
                        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photo));
                        startActivityForResult(cameraIntent, 1);
                    }
                }
                //onActivityResult called when finished (hopefully)
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        if (requestCode == 1) {
            // Make sure the request was successful
            if (resultCode == RESULT_OK)
            {
                File f = new File(fileNameList.get(0)); //get first in array, where path should be stored
                if (f != null)
                {
                    //update cards
                    rAdapter.notifyDataSetChanged();
                    if (fileNameList.size()>0)
                    {
                        txtV.setText("");
                    }
                }
            }
        }
    }

    private File createImageFile() throws IOException
    {
        //create image directory if necessary
        String root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString();
        File dir = new File(root+"/CS185Pics");
        if (!dir.exists())
        {
            dir.mkdirs();
        }
        //Create image file, add to list, increase photoNum
        String imageFileName = "photo_"+photoNum;
        File image = File.createTempFile(imageFileName,".jpg",dir);
        String photoPath = image.getAbsolutePath();
        fileNameList.add(0,photoPath);
        photoNum++;
        return image;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (id)
        {
            case R.id.deleteAll:
                deleteAllPictures(); //if delete all button is pressed, delete everything
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void deleteAllPictures()
    {
        //delete all pictures on disk and in app
        String dirPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+"/CS185Pics";
        File f = new File(dirPath);
        File file[] = f.listFiles();
        for (int i=0;i<file.length;i++)
        {
            file[i].delete();
        }
        //clear path arraylist, reset photoNum
        fileNameList.clear();
        photoNum = 0;
        rAdapter.notifyDataSetChanged();
        txtV.setText("No Photos");
    }

    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>
    {
        public ArrayList<String> photoPaths;
        public class ViewHolder extends RecyclerView.ViewHolder
        {
            public String currPhoto;
            public ImageView photo;
            public ViewHolder(View v)
            {
                super(v);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(v.getContext(), MultiTouchActivity.class);
                        i.putExtra(PHOTO_URL,currPhoto);
                        v.getContext().startActivity(i);
                    }
                });
                photo = (ImageView)v.findViewById(R.id.imageView);
            }
        }

        public MyAdapter(ArrayList<String> photoURLS)
        {
            photoPaths = photoURLS;
        }

        @Override
        public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
        {
            // create a new view
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false);
            //set view's size, margins, paddings and layout parameters
            final float scale = getResources().getDisplayMetrics().density;
            int pSix = (int)(6*scale+0.5f);
            if (photoPaths.size()==0)
            {
                v.setPadding(pSix,pSix,pSix,pSix);
            }
            else
            {
                v.setPadding(pSix,pSix,pSix,0);
            }
            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            holder.currPhoto = photoPaths.get(position);
            File f = new File(photoPaths.get(position));
            Bitmap bitmap = BitmapFactory.decodeFile(f.getAbsolutePath());
            holder.photo.setImageBitmap(bitmap);
        }

        @Override
        public int getItemCount()
        {
            return photoPaths.size();
        }
    }
}

