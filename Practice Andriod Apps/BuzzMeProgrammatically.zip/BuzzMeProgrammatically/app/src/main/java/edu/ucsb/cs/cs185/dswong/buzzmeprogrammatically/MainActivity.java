package edu.ucsb.cs.cs185.dswong.buzzmeprogrammatically;

import android.app.ActionBar;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Vibrator;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main); //Don't use the XML file to build app

        //programmatically create UI
        RelativeLayout r = new RelativeLayout(this);
        r.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,0));

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 0));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,1.0f);
        Button one = new Button(this);
        one.setLayoutParams(p);
        one.setTransformationMethod(null);
        one.setText("One");
        one.setOnClickListener(oneListener);

        Button two = new Button(this);
        two.setLayoutParams(p);
        two.setTransformationMethod(null);
        two.setText("Two");
        two.setOnClickListener(twoListener);

        Button three = new Button(this);
        three.setLayoutParams(p);
        three.setTransformationMethod(null);
        three.setText("Three");
        three.setOnClickListener(threeListener);

        l.addView(one);
        l.addView(two);
        l.addView(three);
        r.addView(l);
        setContentView(r);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private View.OnClickListener oneListener = new View.OnClickListener() {
        public void onClick(View v) {
            // noise once
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP);
            //buzz once
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vib.vibrate(300);
        }
    };

    private View.OnClickListener twoListener = new View.OnClickListener() {
        public void onClick(View v) {
            //noise twice
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
            for (int i=0;i<2;i++)
            {
                tg.startTone(ToneGenerator.TONE_PROP_BEEP);
            }
            //buzz twice
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            for (int j=0;j<2;j++)
            {
                vib.vibrate(300);
            }
        }
    };

    private View.OnClickListener threeListener = new View.OnClickListener() {
        public void onClick(View v) {
            //noise thrice
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
            for (int i=0;i<3;i++)
            {
                tg.startTone(ToneGenerator.TONE_PROP_BEEP);
            }
            //buzz thrice
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            for (int j=0;j<3;j++)
            {
                vib.vibrate(300);
            }
        }
    };
}
