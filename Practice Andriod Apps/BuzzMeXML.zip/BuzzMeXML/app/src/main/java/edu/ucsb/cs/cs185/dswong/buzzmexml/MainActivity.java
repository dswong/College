package edu.ucsb.cs.cs185.dswong.buzzmexml;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Vibrator;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Capture buttons from layout
        Button buttonOne = (Button)findViewById(R.id.button1);
        buttonOne.setOnClickListener(buttonOneListener);

        Button buttonTwo = (Button)findViewById(R.id.button2);
        buttonTwo.setOnClickListener(buttonTwoListener);

        Button buttonThree = (Button)findViewById(R.id.button3);
        buttonThree.setOnClickListener(buttonThreeListener);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Create an anonymous implementation of OnClickListener
    private View.OnClickListener buttonOneListener = new View.OnClickListener() {
        public void onClick(View v) {
            // noise once
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP);
            //buzz once
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vib.vibrate(300);
        }
    };

    private View.OnClickListener buttonTwoListener = new View.OnClickListener() {
        public void onClick(View v) {
            //noise twice
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
            for (int i=0;i<2;i++)
            {
                tg.startTone(ToneGenerator.TONE_PROP_BEEP);
            }
            //buzz twice
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            for (int j=0;j<2;j++)
            {
                vib.vibrate(300);
            }
        }
    };

    private View.OnClickListener buttonThreeListener = new View.OnClickListener() {
        public void onClick(View v) {
            //noise thrice
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
            for (int i=0;i<3;i++)
            {
                tg.startTone(ToneGenerator.TONE_PROP_BEEP);
            }
            //buzz thrice
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            for (int j=0;j<3;j++)
            {
                vib.vibrate(300);
            }
        }
    };
}

